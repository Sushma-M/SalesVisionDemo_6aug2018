Application.$controller("MainPageController", ["$scope", function ($scope) {
    "use strict";
}]);

