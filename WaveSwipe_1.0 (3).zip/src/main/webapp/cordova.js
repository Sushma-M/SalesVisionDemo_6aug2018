/**
 * This is an empty file and it will be replaced by the actual file during mobile app build process.
 */
