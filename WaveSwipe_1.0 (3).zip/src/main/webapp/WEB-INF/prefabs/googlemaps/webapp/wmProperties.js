var _WM_APP_PROPERTIES = {
  "activeTheme" : "default",
  "dateFormat" : "",
  "defaultLanguage" : "en",
  "displayName" : "Googlemaps",
  "homePage" : "Main",
  "name" : "Googlemaps",
  "platformType" : "DEFAULT",
  "securityEnabled" : "false",
  "supportedLanguages" : "en",
  "timeFormat" : "",
  "type" : "PREFAB",
  "version" : "5.7"
};